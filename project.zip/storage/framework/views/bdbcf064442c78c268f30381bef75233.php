<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Brand Names Generator</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>

<body class="gradient-body">
    <header>
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="">
                    <img style="max-width: 120px" src="<?php echo e(asset($front_logo->value) ?? ""); ?>" alt="Logo Here">
                </a>
                
                
                
            </div>
        </nav>
    </header>

    <main class="mt-5 pt-5">
        <section class="mb-5 pb-5">
            <div class="container">
                <div class="mb-5">
                    <h1 class="main-heading">AI-Powered <span class="text-primary"><?php echo e($brand->value ?? ""); ?></span> Text Generator</h1>
                    <p><?php echo e($brand->value ?? ""); ?> name generator powered by AI. Super creative and way too fun.</p>
                </div>
                <div>
                    <div class="row">
                        <div class="col-12 col-lg-8">
                            <p>Generate your unique text for your <?php echo e($product->value ?? ""); ?>:</p>
                            <form id="form">
                                <div class="d-flex gap-3 mb-3">
                                    <input type="text" placeholder="Please say something about yourself, what you like, etc." required id="value" name="prompt" class="form-control">
                                    <button style="max-width: 250px;width: 100%;" type="button" id="generate-btn"
                                        class="btn btn-primary">Generate Text</button>
                                </div>
                            </form>
                            <div class="d-flex gap-3">
                                <div class="form-check">
                                    <input class="form-check-input" name="check-funny" type="checkbox" value=""
                                        id="checkbox-funny">
                                    <label style="user-select: none;cursor: pointer;" class="form-check-label"
                                        for="checkbox-funny">
                                        Make it funny
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="check-romantic" type="checkbox" value=""
                                        id="checkbox-romantic">
                                    <label style="user-select: none;cursor: pointer;" class="form-check-label"
                                        for="checkbox-romantic">
                                        Make it romantic
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" name="check-serious" type="checkbox" value=""
                                        id="checkbox-serious">
                                    <label style="user-select: none;cursor: pointer;" class="form-check-label"
                                        for="checkbox-serious">
                                        Make it serious!
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div id="name-container" class="row mt-5 g-3">
                    <div style="display: none" class="col-12 loader text-center">
                        <div class="spinner-border text-primary"  role="status">
                            <span class="visually-hidden">Loading...</span>
                          </div>
                    </div>
                </div>
            </div>
        </section>

        

    </main>


    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

    <script>
        document.querySelector("#form").addEventListener("submit", e => e.preventDefault())
        const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        const generateBtn = document.querySelector("#generate-btn")
        generateBtn.addEventListener("click", async ()=>{
            generateBtn.disabled = true
            const prompt = document.querySelector("input[name='prompt']").value
            const is_romantic = document.querySelector("input[name='check-romantic']").checked
            const is_serious = document.querySelector("input[name='check-serious']").checked
            const is_funny = document.querySelector("input[name='check-funny']").checked
            const data = {
                prompt,
                is_romantic,
                is_funny,
                is_serious,
            };        
            if (prompt == "") {
                return
            }
            await getSuggestions(data)
            generateBtn.disabled = false
        })     

        async function getSuggestions(data) {
            document.querySelector("#name-container").innerHTML = `<div class="col-12 loader text-center">
                        <div class="spinner-border text-primary"  role="status">
                            <span class="visually-hidden">Loading...</span>
                          </div>
                    </div>`

            const request = await fetch('<?php echo e(route('suggestions')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token 
                },
                body: JSON.stringify(data)
            })
            const response = await request.json()
            console.log(response);


            $markup = ""
            response.data.forEach(name => {
                $markup += `<div class="col-md-3">
                <div class="p-2 border border-primary border-2 text-primary fw-semibold bg-light rounded w-100 text-center">${name}</div>
            </div>`                
            });

            document.querySelector("#name-container").innerHTML = $markup 
        }

    </script>


</body>

</html><?php /**PATH E:\work\technodigg\craig-grossman\project\resources\views/index.blade.php ENDPATH**/ ?>